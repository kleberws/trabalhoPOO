package br.edu.univille.poo2.exemplograficos.model;

/**
 * GenerationType
 */
public class GenerationType {

    public static final jakarta.persistence.GenerationType IDENTITY = null;

}
