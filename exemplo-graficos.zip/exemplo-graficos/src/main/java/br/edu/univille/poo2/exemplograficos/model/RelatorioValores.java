package br.edu.univille.poo2.exemplograficos.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Column;
import jakarta.persistence.JoinColumn;

@Entity
public class RelatorioValores {
    @Id
    @ManyToOne
    @JoinColumn(name = "relatorio_id", nullable = false)
    private Relatorio relatorio;

    @Column(nullable = true)
    private Double valores;

    // Getters and Setters
    public Relatorio getRelatorio() { return relatorio; }
    public void setRelatorio(Relatorio relatorio) { this.relatorio = relatorio; }

    public Double getValores() { return valores; }
    public void setValores(Double valores) { this.valores = valores; }
}
